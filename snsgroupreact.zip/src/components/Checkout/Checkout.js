import React from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Checkout.css'; // Import CSS for styling

const Checkout = () => {
    const { state } = useLocation();
    const { cartItems, totalPrice, customerAddress } = state || { cartItems: [], totalPrice: 0, customerAddress: {} };
    const navigate = useNavigate();

    const handlePlaceOrder = async () => {
        try {
            const token = localStorage.getItem('token');
            const customerId = localStorage.getItem('customer_id');
            await axios.post('http://localhost:3001/order/create', {
                customer_id: customerId
            }, {
                headers: {
                    'authorization': token
                }
            });

            // Navigate to order summary after successful order placement
            navigate('/order-summary');
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="checkout-container">
            <h2>Checkout</h2>
            <div className="customer-address">
                <h3>Customer Address</h3>
                <p>{customerAddress.street}</p>
                <p>{customerAddress.city}, {customerAddress.state} {customerAddress.zip_code}</p>
            </div>
            <div className="product-list">
                <h3>Product List</h3>
                {cartItems.length > 0 ? (
                    <ul>
                        {cartItems.map(item => (
                            <li key={item._id}>
                                <h4>{item.product.name}</h4>
                                <p>Price: ${item.product.price}</p>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No items in cart.</p>
                )}
            </div>
            <div className="checkout-summary">
                <p>Total Price: <strong>${totalPrice.toFixed(2)}</strong></p>
                <button onClick={handlePlaceOrder} className="place-order-button">Place Order</button>
            </div>
        </div>
    );
};

export default Checkout;
