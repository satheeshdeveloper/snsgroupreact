import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './OrderSummary.css'; // Import CSS for styling

const OrderSummary = () => {
    const [order, setOrder] = useState(null);

    useEffect(() => {
        const fetchOrder = async () => {
            try {
                const customerId = localStorage.getItem('customer_id');
                const token = localStorage.getItem('token');
                const response = await axios.get(`http://localhost:3001/order/list/${customerId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'authorization': token
                    }
                });

                // Update the response data structure based on your API response
                setOrder(response.data.data); // Assuming there's only one order in the response
                console.log(response.data.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchOrder();
    }, []);

    if (!order) return <p>Loading...</p>;

    return (
        <div className="order-summary-container">
            <div className="order-items">
                <h3>Ordered Items</h3>
                {order.map((item, index) => (
                    <div key={index} className="order-item">
                        <p><strong>{item.products.name}</strong></p>
                        <p>Price: ${item.products.price}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default OrderSummary;
