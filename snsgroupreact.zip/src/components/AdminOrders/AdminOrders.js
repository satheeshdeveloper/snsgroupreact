import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AdminOrders.css'; // Import CSS for styling

const AdminOrders = () => {
    const [orders, setOrders] = useState([]);
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const checkAdmin = async () => {
            const userType = localStorage.getItem('userType');
            if (userType !== 'admin') {
                navigate('/login');
                return;
            }

            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('http://localhost:3001/order/total_sales', {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'authorization': token
                    }
                });
                setOrders(response.data.data);
                setLoading(false);
            } catch (error) {
                console.error(error);
                navigate('/login');
            }
        };

        checkAdmin();
    }, [navigate]);

    if (loading) return <p>Loading...</p>;

    return (
        <div className="admin-orders-container">
            <h2>All Orders</h2>
            {orders.map((order, index) => (
                <div key={index} className="order-card">
                    <div className="order-header">
                        <h3>Order ID: {order._id}</h3>
                        <p><strong>Date:</strong> {new Date(order.order_date).toLocaleDateString()}</p>
                        <p><strong>Total Amount:</strong> ${order.total_amount}</p>
                    </div>
                    <div className="customer-details">
                        <h4>Customer Details</h4>
                        <p><strong>Name:</strong> {order.customer.name}</p>
                        <p><strong>Email:</strong> {order.customer.email}</p>
                        <p><strong>Address:</strong> {order.customer.address.street}, {order.customer.address.city}, {order.customer.address.state} - {order.customer.address.zip_code}</p>
                    </div>
                    <div className="order-items">
                        <h4>Order Items</h4>
                        {order.products.map((product, productIndex) => (
                            <div key={productIndex} className="product-item">
                                <p><strong>Product Name:</strong> {product.name}</p>
                                <p><strong>Price:</strong> ${product.price}</p>
                                <p><strong>Quantity:</strong> {product.quantity}</p>
                                <p><strong>Category:</strong> {product.category}</p>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default AdminOrders;
