import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import './ProductList.css';
import { useNavigate } from 'react-router-dom';

const ProductList = ({ addToCart }) => {
    const [products, setProducts] = useState([]);
    const [quantities, setQuantities] = useState({}); // Store quantities for each product
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        const fetchProducts = async () => {
            try {
                const response = await axios.get('http://localhost:3001/product/list', {
                    headers: {
                        'authorization': token
                    }
                });
                setProducts(response.data.data);

                // Initialize quantity state for each product with a default value of 1
                const initialQuantities = response.data.data.reduce((acc, product) => {
                    acc[product._id] = 1;
                    return acc;
                }, {});
                setQuantities(initialQuantities);
            } catch (error) {
                navigate('/login');
                console.error(error);
            }
        };
        fetchProducts();
    }, []);

    const handleQuantityChange = (productId, delta) => {
        setQuantities(prevQuantities => ({
            ...prevQuantities,
            [productId]: Math.max(1, prevQuantities[productId] + delta) // Ensure quantity stays at least 1
        }));
    };

    const handleAddToCart = async (product) => {
        const token = localStorage.getItem('token');
        const customerId = localStorage.getItem('customer_id');
            try {
            await axios.post('http://localhost:3001/cart/create', {
                product_id: product._id,
                quantity: quantities[product._id],
                customer_id: customerId
            }, {
                headers: {
                    'authorization': token
                }
            });
  
            addToCart(product); // Call the addToCart function if needed
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="product-list-container">
            <h2>Product List</h2>
            <div className="product-grid">
                {products.map(product => (
                    <div key={uuidv4()} className="product-card">
                        <img src={product.image ? product.image : 'https://static.vecteezy.com/system/resources/previews/006/793/029/original/a4-book-mock-up-with-white-cover-blank-journal-template-design-textbook-with-copy-space-3d-product-illustration-free-vector.jpg'} alt={product.name} className="product-image" />
                        <h3 className="product-name">{product.name}</h3>
                        <p className="product-description">{product.description}</p>
                        <p className="product-price">Price: ${product.price}</p>
                        
                        {/* Quantity Controls */}
                        <div className="quantity-controls">
                            <button onClick={() => handleQuantityChange(product._id, -1)}>-</button>
                            <span>{quantities[product._id]}</span>
                            <button onClick={() => handleQuantityChange(product._id, 1)}>+</button>
                        </div>
                        
                        <button className="add-to-cart-button" onClick={() => handleAddToCart(product)}>Add to Cart</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductList;
