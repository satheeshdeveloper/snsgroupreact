import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Menu.css'; // We will style the menu in this file

const Menu = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        // Remove all session data from localStorage
        localStorage.removeItem('userType');
        localStorage.removeItem('token');
        localStorage.removeItem('customer_id');
        // Redirect to the login page
        navigate('/login');
    };

    const userType = localStorage.getItem('userType');

    return (
        <header className="menu">
            <nav className="navbar">
                <ul>
                    <li><Link to="/products">Products</Link></li>
                    <li><Link to="/cart">Cart</Link></li>
                    {userType === 'admin' && <li><Link to="/all-orders">All Orders</Link></li>}
                    {localStorage.getItem('token') ? (
                        <li><button className="logout-button" onClick={handleLogout}>Logout</button></li>
                    ) : (
                        <>
                            <li><Link to="/login">Login</Link></li>
                            <li><Link to="/signup">Signup</Link></li>
                        </>
                    )}
                </ul>
            </nav>
        </header>
    );
};

export default Menu;
