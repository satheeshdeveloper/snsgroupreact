import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Cart.css'; // Import CSS for styling


const Cart = () => {
    const [cartItems, setCartItems] = useState([]);
    const [totalPrice, setTotalPrice] = useState(0);
    const [customerAddress, setCustomerAddress] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const fetchCartItems = async () => {
            const customerId = localStorage.getItem('customer_id');
            const token = localStorage.getItem('token');
            const address = JSON.parse(localStorage.getItem('address')) || {};
            setCustomerAddress(address);

            try {
                const response = await axios.get(`http://localhost:3001/cart/list/${customerId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'authorization': token
                    }
                });

                setCartItems(response.data.data);

                // Calculate total price
                const total = response.data.data.reduce((total, item) => total + item.product.price, 0);
                setTotalPrice(total);
            } catch (error) {
                console.error(error);
                navigate('/login');
            }
        };

        fetchCartItems();
    }, []);

    const handleProceedToCheckout = () => {
        navigate('/checkout', { state: { cartItems, totalPrice, customerAddress } });
    };

    return (
        <div className="cart-container">
            <h2>Shopping Cart</h2>
            {cartItems.length > 0 ? (
                <ul className="cart-items">
                    {cartItems.map(item => (
                        <li key={item._id} className="cart-item">
                            <div className="cart-item-details">
                                <h3>{item.product.name}</h3>
                                <p>Price: ${item.product.price}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>Your cart is empty.</p>
            )}

            <div className="cart-summary">
                <p>Total Price: <strong>${totalPrice.toFixed(2)}</strong></p>
                <button className="checkout-button" onClick={handleProceedToCheckout}>Proceed to Checkout</button>
            </div>
        </div>
    );
};

export default Cart;
