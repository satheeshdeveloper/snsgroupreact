import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login/Login';
import Signup from './components/Signup/Signup';
import ProductList from './components/ProductList/ProductList';
import Cart from './components/Cart/Cart';
import Checkout from './components/Checkout/Checkout';
import OrderSummary from './components/OrderSummary/OrderSummary';
import AdminOrder from './components/AdminOrders/AdminOrders';
import Menu from './components/Menu/Menu';


function App() {
    const [cartItems, setCartItems] = useState([]);

    const addToCart = (product) => {
        setCartItems([...cartItems, product]);
    };

    const removeFromCart = (productId) => {
        setCartItems(cartItems.filter(item => item.id !== productId));
    };

    return (
        <Router>
            <Menu />
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/products" element={<ProductList />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/checkout" element={<Checkout cartItems={cartItems} />} />
                <Route path="/order-summary" element={<OrderSummary />} />
                <Route path="/all-orders" element={<AdminOrder />} />
                <Route path="/" element={<Login />} />
            </Routes>
        </Router>
    );
}

export default App;
